========================================
EXECUTIVE SUMMARY PLATFORM - OFFLINE DEPLOYMENT
========================================

This package contains everything needed to run the Executive Summary Platform on a Windows system WITHOUT internet access.

CONTENTS:
---------
1. frontend/       - Main dashboard (static HTML/JS/CSS)
2. backend/        - API server + CMS admin panel
3. node_modules/   - All required dependencies (bundled)

SYSTEM REQUIREMENTS:
-------------------
- Windows 10/11 or Windows Server 2019+
- Node.js 18+ (must be pre-installed on the target system)
- 500MB free disk space

INSTALLATION STEPS:
------------------

STEP 1: Extract Files
   - Extract this ZIP to: C:\ExecSummary
   - Ensure all files are in: C:\ExecSummary\deployment-package\

STEP 2: Dependencies Already Included!
   ✅ All node_modules are pre-installed in this package
   ✅ NO npm install needed
   ✅ NO internet connection required
   
   Skip to Step 3!

STEP 3: Start the Backend Server
   - In PowerShell: cd C:\ExecSummary\deployment-package\backend
   - Run: node server.js
   
   You should see:
   "Backend API server running on http://localhost:3001"
   "Serving CMS Admin from http://localhost:3001/cms-admin"

STEP 4: Access the Application
   - Main Dashboard: Open C:\ExecSummary\deployment-package\frontend\index.html in browser
   - CMS Admin Panel: http://localhost:3001/cms-admin

   OR use a simple HTTP server for the frontend:
   - Run: npx http-server C:\ExecSummary\deployment-package\frontend -p 8080
   - Access: http://localhost:8080

STEP 5: Create Windows Service (OPTIONAL - for auto-start)
   - Install node-windows: npm install -g node-windows
   - Create service script (see service-install.js below)
   - Run: node service-install.js

FOLDER STRUCTURE:
----------------
deployment-package/
├── frontend/           # Main dashboard (double-click index.html to open)
│   ├── index.html
│   └── assets/         # JS, CSS, fonts, images (all bundled)
│
├── backend/            # API server
│   ├── server.js       # Main server file
│   ├── package.json    # Dependencies list
│   ├── api/            # API routes
│   ├── data/           # JSON data storage
│   │   ├── summaries/  # Executive summaries
│   │   ├── goals/      # Goals and objectives
│   │   ├── templates/  # Content templates
│   │   └── organizations/ # Organization data
│   ├── uploads/        # User uploaded files
│   ├── public/         # Public assets
│   └── cms-admin/      # Built CMS admin panel
│       ├── index.html
│       └── assets/
│
└── README.txt          # This file

DATA LOCATIONS:
--------------
- Executive Summaries: backend/data/summaries/*.json
- Goals: backend/data/goals/goals.json
- Organizations: backend/data/organizations/*.json
- Templates: backend/data/templates/*.json
- Uploaded Files: backend/uploads/

CONFIGURATION:
-------------
To change the backend port (default: 3001):
   - Edit backend/server.js
   - Change: const PORT = process.env.PORT || 3001;
   - Update frontend API calls if needed

TROUBLESHOOTING:
---------------
1. "Cannot find module 'express'"
   → Run: cd backend && npm install

2. "Port 3001 already in use"
   → Kill existing process: taskkill /F /IM node.exe
   → Or change port in backend/server.js

3. Frontend shows "Network Error"
   → Ensure backend is running (node server.js)
   → Check backend URL in frontend matches

4. CMS Admin won't load
   → Verify backend/cms-admin/ folder exists
   → Access via: http://localhost:3001/cms-admin

5. Double-clicking index.html shows CORS errors
   → Use http-server: npx http-server frontend -p 8080
   → Or configure browser to allow file:// CORS

SECURITY NOTES:
--------------
- Default login: admin / password123 (CHANGE THIS!)
- Backend has NO authentication by default (add if internet-facing)
- Data stored in plain JSON files (consider encryption for sensitive data)
- HTTPS not configured (add reverse proxy if needed)

CREATING A WINDOWS SERVICE:
--------------------------
Create file: backend/service-install.js

```javascript
const Service = require('node-windows').Service;

const svc = new Service({
  name: 'Executive Summary Platform',
  description: 'Executive Summary Backend API Server',
  script: 'C:\\ExecSummary\\deployment-package\\backend\\server.js',
  nodeOptions: ['--harmony', '--max_old_space_size=4096']
});

svc.on('install', () => {
  svc.start();
  console.log('Service installed and started!');
});

svc.install();
```

Run: node backend/service-install.js

BACKUP RECOMMENDATIONS:
----------------------
Backup these folders regularly:
   - backend/data/        (all user content)
   - backend/uploads/     (uploaded files)

UPDATES:
--------
To update the application:
   1. Stop the backend server (Ctrl+C)
   2. Replace frontend/ and backend/ folders
   3. Run: cd backend && npm install
   4. Restart: node server.js

SUPPORT:
--------
For questions or issues, refer to the main project documentation.

VERSION: December 2025
PLATFORM: Node.js + React + Vite
========================================
