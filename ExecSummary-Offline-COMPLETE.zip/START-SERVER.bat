@echo off
echo ========================================
echo Executive Summary Platform - Quick Start
echo ========================================
echo.

echo [1/3] Checking Node.js installation...
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js is not installed!
    echo Please install Node.js 18+ before running this script.
    echo Download from: https://nodejs.org/
    pause
    exit /b 1
)
echo Node.js found: 
node --version

echo.
echo [2/3] Checking dependencies...
cd backend
if exist "node_modules" (
    echo Dependencies already installed (node_modules found)
) else (
    echo ERROR: node_modules folder missing!
    echo This package should include pre-installed dependencies.
    pause
    exit /b 1
)

echo.
echo [3/3] Starting backend server...
echo.
echo ========================================
echo SERVER STARTING
echo ========================================
echo Backend API:  http://localhost:3001
echo CMS Admin:    http://localhost:3001/cms-admin
echo Frontend:     Open ../frontend/index.html in browser
echo ========================================
echo.
echo Press Ctrl+C to stop the server
echo.

node server.js
