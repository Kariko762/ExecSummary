# Executive Summary Platform - PowerShell Startup Script

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Executive Summary Platform - Quick Start" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1/3] Checking Node.js installation..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version
    Write-Host "Node.js found: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Node.js is not installed!" -ForegroundColor Red
    Write-Host "Please install Node.js 18+ before running this script." -ForegroundColor Red
    Write-Host "Download from: https://nodejs.org/" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Host "[2/3] Checking dependencies..." -ForegroundColor Yellow
Set-Location backend

if (Test-Path "node_modules") {
    Write-Host "Dependencies already installed (node_modules found)" -ForegroundColor Green
} else {
    Write-Host "ERROR: node_modules folder missing!" -ForegroundColor Red
    Write-Host "This package should include pre-installed dependencies." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Host "[3/3] Starting backend server..." -ForegroundColor Yellow
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "SERVER STARTING" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Backend API:  http://localhost:3001" -ForegroundColor Green
Write-Host "CMS Admin:    http://localhost:3001/cms-admin" -ForegroundColor Green
Write-Host "Frontend:     Open ../frontend/index.html in browser" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

node server.js
